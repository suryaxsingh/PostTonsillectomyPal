/* generated */
const CACHE = "ptpal-mv67xn0b";
const FILES = ["./","./assets/index-vxZmJvfP.js","./assets/caprasimo-latin-400-normal-CPOhBPz8.woff","./assets/caprasimo-latin-400-normal-u3avbpQ7.woff2","./assets/figtree-latin-400-normal-BD4aNku5.woff","./assets/figtree-latin-400-normal-g7Dtegnw.woff2","./assets/figtree-latin-500-normal-BWnGEVsr.woff2","./assets/figtree-latin-500-normal-B_yy1phn.woff","./assets/figtree-latin-600-normal-BM_oTo4n.woff","./assets/figtree-latin-600-normal-Cv_xCTDl.woff2","./assets/figtree-latin-700-normal-BCCt2T1q.woff","./assets/figtree-latin-700-normal-th6qEP7c.woff2","./assets/figtree-latin-800-normal-30yxI7TZ.woff2","./assets/figtree-latin-800-normal-B7vj2UK8.woff","./assets/index-DR84Wx3I.css","./icons/apple-touch-icon.png","./icons/icon-192.png","./icons/icon-512.png","./icons/icon-maskable-512.png","./icons/icon.svg","./manifest.webmanifest"];
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()),
  );
});
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  if (e.request.mode === "navigate") {
    e.respondWith(fetch(e.request).catch(() => caches.match("./")));
    return;
  }
  e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request)));
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => (list[0] ? list[0].focus() : self.clients.openWindow("./"))),
  );
});
